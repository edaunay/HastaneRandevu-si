package com.example.hastanerandevu.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User(
    @PrimaryKey
    val tcNo: Long,
    val nameAndSurname: String,
    val password: String
)
