package com.example.hastanerandevu.db

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.hastanerandevu.model.Appointment
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.User

@Dao
interface AppointmentDao {

    @Insert
    suspend fun addAppointment(appointment: Appointment)

    @Query("select * from Appointment where tcNo= :tcNo")
    fun myAppointment(tcNo: Long): List<Appointment>




}