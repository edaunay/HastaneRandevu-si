package com.example.hastanerandevu.views.activity

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityPoliclinicSelectBinding
import com.example.hastanerandevu.databinding.LayoutDetailAppointmentBinding
import com.example.hastanerandevu.databinding.LayoutFinishAppointmentBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.model.Appointment
import com.example.hastanerandevu.model.Hospital
import com.example.hastanerandevu.model.Policlinic
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory
import com.example.hastanerandevu.views.adapter.PoliclinicSelectAdapter
import java.text.SimpleDateFormat
import java.util.*


class PoliclinicSelectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPoliclinicSelectBinding

    lateinit var mainViewModel: MainViewModel

    private lateinit var policlinicSelectAdapter: PoliclinicSelectAdapter

    private lateinit var sharedPrefUtils: SharedPrefUtils

    private var year = 0
    private var month = 0
    private var day = 0
    private lateinit var calendar: Calendar
    var selectedDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPoliclinicSelectBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = ContextCompat.getColor(this, R.color.color_green)

        sharedPrefUtils = SharedPrefUtils(this)

        val mainRepository = MainRepository(AppDatabase(this))
        val viewModelProviderFactory = MainViewModelFactory(application, mainRepository)

        mainViewModel = ViewModelProvider(this, viewModelProviderFactory)[MainViewModel::class.java]

        val hospital = intent.getParcelableExtra<Hospital>("hospital")

        binding.textViewHospitalName.text = hospital?.hospitalName

        binding.imageViewBack.setOnClickListener {
            finish()
        }

        initRv(hospital)


    }

    private fun initRv(hospital: Hospital?) {
        policlinicSelectAdapter = PoliclinicSelectAdapter(mainViewModel.getPoliclinic())
        policlinicSelectAdapter.policlinicSelectListener =
            object : PoliclinicSelectAdapter.PoliclinicSelectListener {
                override fun onSelect(policlinic: Policlinic) {
                    selectDate(hospital, policlinic)
                }

            }
        binding.recyclerViewPoliclinic.apply {
            layoutManager = LinearLayoutManager(this@PoliclinicSelectActivity)
            setHasFixedSize(true)
            adapter = policlinicSelectAdapter
        }
    }

    private fun selectDate(hospital: Hospital?, policlinic: Policlinic) {
        calendar = Calendar.getInstance()
        year = calendar.get(Calendar.YEAR)
        month = calendar.get(Calendar.MONTH)
        day = calendar.get(Calendar.DAY_OF_MONTH)
        val myFormat = "dd/MM/yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.getDefault())
        val dialog = DatePickerDialog(this, { _, year, month, day_of_month ->
            calendar[Calendar.YEAR] = year
            calendar[Calendar.MONTH] = month + 1
            calendar[Calendar.DAY_OF_MONTH] = day_of_month
            selectedDate = sdf.format(calendar.time)
            showDetailDialog(selectedDate, hospital, policlinic)

        }, calendar[Calendar.YEAR], calendar[Calendar.MONTH], calendar[Calendar.DAY_OF_MONTH])
        dialog.datePicker.minDate = calendar.timeInMillis
        calendar.add(Calendar.YEAR, 0)

        dialog.show()

    }

    private fun showDetailDialog(
        selectedDate: String,
        hospital: Hospital?,
        policlinic: Policlinic
    ) {

        var layoutEightSelect = false
        var layoutNineSelect = false

        val builder: AlertDialog.Builder =
            AlertDialog.Builder(this, R.style.FullscreenAlertDialogStyle)
        val alert = builder.create()

        val binding = LayoutDetailAppointmentBinding.inflate(LayoutInflater.from(this), null, false)
        alert.setView(binding.root)

        binding.textViewDate.text = selectedDate

        binding.textViewSelectTime1.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTime1.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.textViewSelectTime2.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTime2.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.textViewSelectTime3.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTime3.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.textViewSelectTimeNine.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTimeNine.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.textViewSelectTimeNine2.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTimeNine2.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.textViewSelectTimeNine3.setOnClickListener {
            finishAppointment(
                binding.textViewSelectTimeNine3.text.toString(),
                selectedDate,
                hospital,
                policlinic
            )
        }

        binding.layoutEight.setOnClickListener {
            binding.layoutNineSelected.visibility = View.GONE
            binding.imageViewSelectNine.rotation = 0F
            layoutNineSelect = false
            if (!layoutEightSelect) {
                layoutEightSelect = true
                binding.layoutEightSelected.visibility = View.VISIBLE
                binding.imageViewSelect.rotation = 90F
            } else {
                layoutEightSelect = false
                binding.layoutEightSelected.visibility = View.GONE
                binding.imageViewSelect.rotation = 0F
            }
        }

        binding.layoutNine.setOnClickListener {
            binding.layoutEightSelected.visibility = View.GONE
            binding.imageViewSelect.rotation = 0F
            layoutEightSelect = false

            if (!layoutNineSelect) {
                layoutNineSelect = true
                binding.layoutNineSelected.visibility = View.VISIBLE
                binding.imageViewSelectNine.rotation = 90F
            } else {
                layoutNineSelect = false
                binding.layoutNineSelected.visibility = View.GONE
                binding.imageViewSelectNine.rotation = 0F
            }
        }



        alert.show()

    }

    private fun finishAppointment(
        time: String,
        selectedDate: String,
        hospital: Hospital?,
        policlinic: Policlinic
    ) {
        val myInfo = sharedPrefUtils.getUser()

        val builder: AlertDialog.Builder =
            AlertDialog.Builder(this, R.style.FullscreenAlertDialogStyle)
        val alert = builder.create()

        val binding = LayoutFinishAppointmentBinding.inflate(LayoutInflater.from(this), null, false)
        alert.setView(binding.root)

        binding.textViewDate.text = selectedDate
        binding.textViewHospitalName.text = hospital?.hospitalName
        binding.textViewPoliclinicName.text = policlinic.clinicName
        binding.textViewName.text = myInfo?.nameAndSurname
        binding.textViewTime.text = time
        binding.textViewDoctorName.text = policlinic.doctorName

        binding.buttonSuccess.setOnClickListener {
            val appointment = Appointment(
                0,
                hospital!!.hospitalName,
                hospital.hospitalCity,
                policlinic.clinicName,
                policlinic.doctorName,
                myInfo!!.tcNo,
                myInfo.nameAndSurname,
                selectedDate,
                time
            )
            mainViewModel.addAppointment(appointment)
            val intent = Intent(this@PoliclinicSelectActivity,MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        binding.buttonCancel.setOnClickListener {
            alert.dismiss()
        }

        alert.show()


    }

}