package com.example.hastanerandevu.views.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.example.hastanerandevu.R
import com.example.hastanerandevu.databinding.ActivityLoginBinding
import com.example.hastanerandevu.db.AppDatabase
import com.example.hastanerandevu.repository.MainRepository
import com.example.hastanerandevu.utils.SharedPrefUtils
import com.example.hastanerandevu.viewmodel.MainViewModel
import com.example.hastanerandevu.viewmodel.MainViewModelFactory

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sharedPrefUtils: SharedPrefUtils
    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sharedPrefUtils = SharedPrefUtils(this)
        val mainRepository = MainRepository(AppDatabase(this))
        val viewModelProviderFactory = MainViewModelFactory(application,mainRepository)

        mainViewModel = ViewModelProvider(this,viewModelProviderFactory)[MainViewModel::class.java]


        binding.textViewGoRegister.setOnClickListener {
            goToRegister()
        }

        binding.buttonLogin.setOnClickListener {
            val tcNo = binding.editTextTc.text.toString().toLong()
            val password = binding.editTextPassword.text.toString()
            mainViewModel.loginUser(tcNo, password).observe(this) {
                if (it.isEmpty()) {
                    Toast.makeText(this, "Bilgileri kontrol edin", Toast.LENGTH_SHORT).show()
                } else {
                    sharedPrefUtils.setUser(it[0])
                    goToHome()
                }
            }

        }
    }

    private fun goToRegister() {
        val intent = Intent(this,RegisterActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun goToHome() {
        val intent = Intent(this,MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}